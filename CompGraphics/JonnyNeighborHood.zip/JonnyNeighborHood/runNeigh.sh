#!/bin/bash
javac -cp "../jar/jogl-all.jar:../jar/gluegen-rt.jar:." NeighborHood.java && java -cp "../jar/jogl-all.jar:../jar/gluegen-rt.jar:." NeighborHood