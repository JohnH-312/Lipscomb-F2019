My Suprise is a (Somewhat)working Frogger Game
There is a little frog character you can move across the street with WASD keys.
This as well as the cars moving should meet both the car and animation requirements
I had initially had other plans completely, originally I wanted to get bump maps working
But there was very little resources online on them, and I spent multiple hours scouring 
the Internet trying to figure it out to no avail.
My original plan for the Suprise was to get a working SkyBox, but the resources online i 
found for that relied on lots of external plugins and shaders i didn't feel like 
familiarizing myself with or requireing you to download to get it working.

I included some code from https://www.tutorialspoint.com/jogl/jogl_lighting.htm 
to get the lighting to work
I pulled some code from the JOGL Starter.java to get the Key Presses working.
Some code has been recycled from the remains of previous homeworks, 
to use as templates for new objects.

again Camera is my modified version Camera2 which restricts the viewing region.