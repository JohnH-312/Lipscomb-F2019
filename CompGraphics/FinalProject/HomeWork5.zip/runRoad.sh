#!/bin/bash
javac -cp "../jar/jogl-all.jar:../jar/gluegen-rt.jar:." RoadScene.java && java -cp "../jar/jogl-all.jar:../jar/gluegen-rt.jar:." RoadScene