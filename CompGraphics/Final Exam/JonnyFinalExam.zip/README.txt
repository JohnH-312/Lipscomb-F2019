I chose to use Eck's Camera, which I have named Camera.java
The controlls are the same as Eck's
Most of the other feautures are based on JoglStarter with some inspiration from previous assignments, 
such as textures from my RoadScence and various lighting setup from the HouseAndTable as well as normal calculation from the BiPyrmaid.
This is merely for the convenience of not having to write it all out again.
