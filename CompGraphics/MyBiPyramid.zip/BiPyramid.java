import java.awt.*;
import javax.swing.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.*;

import com.jogamp.opengl.util.FPSAnimator; 



public class BiPyramid extends GLJPanel implements GLEventListener{
    
    /**
     * A main routine to create and show a window that contains a
     * panel of type BiPyramid.  The program ends when  the
     * user closes the window.
     */
    public static void main(String[] args) {
        JFrame window = new JFrame("Hey! Take a look at my Bi-Pyramid");
        BiPyramid panel = new BiPyramid();
        window.setContentPane((Container) panel);
        window.pack();
        window.setLocation(50,50);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);   
  
    }
    
    /**
     * Constructor for class BiPyramid.
     */
    public BiPyramid() {
        super( new GLCapabilities(null) ); // Makes a panel with default OpenGL "capabilities".
        setPreferredSize( new Dimension(500,500) );
        addGLEventListener(this); // A listener is essential! The listener is where the OpenGL programming lives.
    }
    
    
    //-------------------- GLEventListener Methods -------------------------

    /**
     * The display method is called when the panel needs to be redrawn.
     * The is where the code goes for drawing the image, using OpenGL commands.
     */
    public void display(GLAutoDrawable drawable) {    
        
        GL2 gl2 = drawable.getGL().getGL2(); // The object that contains all the OpenGL methods.
         
        gl2.glClearColor( 0, 0, 0, 1 );  // (In fact, this is the default.)
        gl2.glClear( GL2.GL_COLOR_BUFFER_BIT );
        gl2.glEnable(GL2.GL_DEPTH_TEST);
        
        //Here it be, my Bi-Pyramid
        gl2.glScalef(1.0f, 1.0f, -1.0f);
        gl2.glRotatef(33f, 1.0f, 2.0f, 0.0f);

        gl2.glBegin(GL2.GL_TRIANGLES);           // Begin drawing the pyramid with 4 triangles

        float[][] vertexList =
            {   {0.0f, 1.0f, 0.0f},         //0
                {-0.25f, 0.0f, 0.50f},      //1
                {0.25f, 0.0f, 0.50f},       //2 
                {0.45f, 0.0f, 0.0f},        //3 
                {0.25f, 0.0f, -0.50f},      //4
                {-0.25f, 0.0f, -0.50f},     //5
                {-0.45f, 0.0f, 0.0f},       //6
                {0.0f, -1.0f, 0.0f}         //7
            };
         
        int[][] faceList =
            {   {0,1,2},    //0
                {0,2,3},    //1 
                {0,3,4},    //2
                {0,4,5},    //3
                {0,5,6},    //4 
                {0,6,1},    //5
                {7,1,2},    //6
                {7,2,3},    //7
                {7,3,4},    //8
                {7,4,5},    //9
                {7,5,6},    //10
                {7,6,1}     //11
            };
        
        float[][] faceColors = 
            {
                {0.451f, 0.000f, 0.847f},     //Electric Violet
                {0.847f, 0.451f, 0.0f},     //MangoTango
                {0.451f, 0.000f, 0.847f},     //Electric Violet
                {0.847f, 0.451f, 0.0f},     //MangoTango
                {0.451f, 0.000f, 0.847f},     //Electric Violet
                {0.847f, 0.451f, 0.0f},     //MangoTango
                {0.000f, 0.847f, 0.451f},     //Carribean Green
                {0.0f, 0.396f, 0.847f},     //ScienceBLue
                {0.000f, 0.847f, 0.451f},     //Carribean Green
                {0.0f, 0.396f, 0.847f},     //ScienceBLue
                {0.000f, 0.847f, 0.451f},     //Carribean Green
                {0.0f, 0.396f, 0.847f},     //ScienceBLue
            };

        for (int i = 0; i < faceList.length; i++) {
            gl2.glColor3f( faceColors[i][0], faceColors[i][1], faceColors[i][2]);  // Set color for face number i.
            gl2.glBegin(GL2.GL_TRIANGLES);
            for (int j = 0; j < faceList[i].length; j++) {
                int vertexNum = faceList[i][j];  // Index for vertex j of face i.
                float[] vertexCoords = vertexList[vertexNum];  // The vertex itself.
                gl2.glVertex3f(vertexCoords[0], vertexCoords[1], vertexCoords[2]);
            }
            gl2.glEnd();
        }

        
    } // end display()

    public void init(GLAutoDrawable drawable) {
           // called when the panel is created
    }

    public void dispose(GLAutoDrawable drawable) {
            // called when the panel is being disposed
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
            // called when user resizes the window

    }
    
}