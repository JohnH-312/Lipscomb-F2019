I included some code from https://www.tutorialspoint.com/jogl/jogl_lighting.htm 
to get the lighting to work
I edited my Old House from the neighborhood, the BiPyramid to Sit on the table.
I also got some other lighting code from Eck's Teapot with multiple light source example(LightandMaterial.java).